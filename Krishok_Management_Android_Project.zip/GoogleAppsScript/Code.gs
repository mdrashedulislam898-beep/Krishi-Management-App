const SHEET_NAME = 'কৃষি_তথ্য';
const HEADERS = ['id','category','name','father','mobile','nid','address','details','updated'];

function doGet() {
  const rows = getRows_();
  return ContentService.createTextOutput(JSON.stringify({ok:true, records:rows}))
    .setMimeType(ContentService.MimeType.JSON);
}
function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    const incoming = body.records || [];
    const sh = getSheet_();
    const values = sh.getDataRange().getValues();
    const idToRow = {};
    for (let i=1;i<values.length;i++) idToRow[String(values[i][0])] = i+1;
    incoming.forEach(rec => {
      const row = HEADERS.map(k => rec[k] == null ? '' : rec[k]);
      const oldRow = idToRow[String(rec.id)];
      if (oldRow) sh.getRange(oldRow,1,1,HEADERS.length).setValues([row]);
      else sh.appendRow(row);
    });
    return ContentService.createTextOutput(JSON.stringify({ok:true, records:getRows_()}))
      .setMimeType(ContentService.MimeType.JSON);
  } catch(err) {
    return ContentService.createTextOutput(JSON.stringify({ok:false,error:String(err)}))
      .setMimeType(ContentService.MimeType.JSON);
  }
}
function getSheet_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  if (sh.getLastRow() === 0) sh.appendRow(HEADERS);
  return sh;
}
function getRows_() {
  const sh = getSheet_(), values = sh.getDataRange().getValues();
  return values.slice(1).filter(r=>r[0]).map(r=>{
    const o={}; HEADERS.forEach((h,i)=>o[h]=String(r[i] == null ? '' : r[i])); return o;
  });
}
