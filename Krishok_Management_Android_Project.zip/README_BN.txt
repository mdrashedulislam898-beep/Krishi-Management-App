কৃষক তথ্য ব্যবস্থাপনা — Android প্রকল্প
========================================

বৈশিষ্ট্য
- কৃষক তালিকা, অগ্রাধিকার তালিকা, মাস্টার, কৃষক দল, প্রণোদনা, প্রদর্শনী
- মোবাইলে SQLite ডাটাবেজে অফলাইন সংরক্ষণ
- Google Sheets-এ সিঙ্ক করার জন্য Apps Script সংযোগ
- নতুন তথ্য, সম্পাদনা, মুছে ফেলা এবং তালিকা দেখা

গুরুত্বপূর্ণ
এই ZIP হলো Android Studio-তে APK বানানোর সোর্স প্রজেক্ট; এটি নিজে থেকে APK ফাইল নয়।
এখানে Android SDK/Gradle build চালানো হয়নি, তাই APK তৈরি হয়েছে বলে দাবি করা হচ্ছে না।

APK তৈরির ধাপ
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. এই ZIP Extract করে Android Studio-তে Open করুন।
3. Gradle Sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন।
4. app/build/outputs/apk/debug/app-debug.apk থেকে APK নিন।
5. ফোনে APK পাঠিয়ে Install করুন। অজানা উৎস থেকে ইনস্টল করার অনুমতি চাইতে পারে।

Google Sheets সংযোগ
1. একটি নতুন Google Sheet খুলুন।
2. Extensions > Apps Script খুলুন।
3. GoogleAppsScript/Code.gs ফাইলের কোড কপি করে Apps Script-এ পেস্ট করুন।
4. Deploy > New deployment > Web app নির্বাচন করুন।
5. Execute as: Me; Who has access: Anyone (প্রতিষ্ঠানের নীতিমালা অনুমতি দিলে)।
6. Deploy করে Web App URL কপি করুন।
7. Android অ্যাপে Google Sheets সংযোগ স্ক্রিনে URL পেস্ট করে Save করুন, তারপর Sync চাপুন।

সতর্কতা
- NID ও মোবাইল নম্বর ব্যক্তিগত তথ্য। Google Sheet-এ প্রবেশাধিকার সীমিত রাখুন।
- এই প্রাথমিক সংস্করণে সব বিভাগের তথ্য সাধারণ ফিল্ড ও অতিরিক্ত তথ্য ঘরে রাখা হয়।
- একই রেকর্ড একাধিক ফোনে একসঙ্গে সম্পাদনা করলে পরের Sync-এ সর্বশেষ আপলোড করা সংস্করণ কার্যকর হতে পারে।
- প্রথমবার সিঙ্কে ফোনের নতুন তথ্য Google Sheet-এ পাঠানো হয়; Google Sheet থেকে আসা তথ্য ফোনে যুক্ত হয়।
