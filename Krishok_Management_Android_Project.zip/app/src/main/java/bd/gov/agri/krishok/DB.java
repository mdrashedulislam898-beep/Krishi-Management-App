package bd.gov.agri.krishok;

import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import org.json.*;
import java.util.*;

public class DB extends SQLiteOpenHelper {
    public DB(Context c){ super(c,"krishok.db",null,1); }
    public void onCreate(SQLiteDatabase d){
        d.execSQL("CREATE TABLE records(id TEXT PRIMARY KEY, category TEXT, name TEXT, father TEXT, mobile TEXT, nid TEXT, address TEXT, details TEXT, updated TEXT, synced INTEGER DEFAULT 0)");
    }
    public void onUpgrade(SQLiteDatabase d,int o,int n){}
    public JSONArray all(){
        JSONArray a=new JSONArray(); Cursor c=getReadableDatabase().rawQuery("SELECT * FROM records ORDER BY updated DESC",null);
        while(c.moveToNext()){ JSONObject x=new JSONObject(); try{
            String[] k={"id","category","name","father","mobile","nid","address","details","updated"};
            for(int i=0;i<k.length;i++) x.put(k[i],c.getString(i));
            x.put("synced",c.getInt(9)==1); a.put(x);
        }catch(Exception e){} } c.close(); return a;
    }
    public void save(JSONObject x, boolean synced){
        SQLiteDatabase d=getWritableDatabase(); ContentValues v=new ContentValues();
        String[] k={"id","category","name","father","mobile","nid","address","details","updated"};
        for(String s:k) v.put(s,x.optString(s,""));
        v.put("synced",synced?1:0); d.insertWithOnConflict("records",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    public JSONArray pending(){
        JSONArray a=new JSONArray(); Cursor c=getReadableDatabase().rawQuery("SELECT * FROM records WHERE synced=0",null);
        while(c.moveToNext()){ JSONObject x=new JSONObject(); try{
            String[] k={"id","category","name","father","mobile","nid","address","details","updated"};
            for(int i=0;i<k.length;i++) x.put(k[i],c.getString(i)); a.put(x);
        }catch(Exception e){} } c.close(); return a;
    }
    public void markAllSynced(){ getWritableDatabase().execSQL("UPDATE records SET synced=1"); }
    public int count(String cat){ Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM records WHERE category=?",new String[]{cat}); c.moveToFirst(); int n=c.getInt(0); c.close(); return n; }
    public void delete(String id){ getWritableDatabase().delete("records","id=?",new String[]{id}); }
}
