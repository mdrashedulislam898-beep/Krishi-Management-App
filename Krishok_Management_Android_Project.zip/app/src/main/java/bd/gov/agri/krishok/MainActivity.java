package bd.gov.agri.krishok;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    DB db; LinearLayout root, body; EditText endpoint;
    String[] cats={"কৃষক তালিকা","অগ্রাধিকার তালিকা","মাস্টার","কৃষক দল","প্রণোদনা","প্রদর্শনী"};
    String selected=cats[0];
    int green=0xFF237A45;
    public void onCreate(Bundle b){super.onCreate(b); db=new DB(this); showHome();}
    TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFF183323); t.setPadding(12,10,12,10); return t; }
    Button btn(String s,Runnable r){ Button b=new Button(this); b.setText(s); b.setOnClickListener(v->r.run()); return b; }
    void start(String title){
        root=new LinearLayout(this); root.setOrientation(1); root.setPadding(14,14,14,14); root.setBackgroundColor(0xFFF5F8F5);
        TextView h=text(title,22); h.setTypeface(null,Typeface.BOLD); h.setTextColor(green); root.addView(h);
        ScrollView sc=new ScrollView(this); body=new LinearLayout(this); body.setOrientation(1); sc.addView(body); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }
    void showHome(){
        start("কৃষক তথ্য ব্যবস্থাপনা");
        body.addView(text("অফলাইনেও তথ্য সংরক্ষণ হবে। ইন্টারনেট পেলে Google Sheets-এ সিঙ্ক করুন।",14));
        for(String c:cats) body.addView(text(c+" : "+db.count(c)+" টি",17));
        body.addView(btn("＋ নতুন তথ্য যোগ করুন",()->chooseCategory()));
        for(String c:cats) body.addView(btn(c+" দেখুন",()->showList(c)));
        body.addView(btn("Google Sheets সংযোগ / Sync",()->settings()));
    }
    void chooseCategory(){
        new AlertDialog.Builder(this).setTitle("কোন তালিকায় তথ্য যোগ করবেন?")
          .setItems(cats,(d,w)->showForm(cats[w],null)).show();
    }
    EditText field(LinearLayout box,String hint,String val){
        EditText e=new EditText(this); e.setSingleLine(false); e.setHint(hint); if(val!=null)e.setText(val); box.addView(e); return e;
    }
    void showForm(String cat,JSONObject old){
        start(cat+" — তথ্য যোগ");
        EditText name=field(body,"নাম / শিরোনাম",old==null?"":old.optString("name"));
        EditText father=field(body,"পিতা/মাতার নাম",old==null?"":old.optString("father"));
        EditText mobile=field(body,"মোবাইল নম্বর",old==null?"":old.optString("mobile"));
        EditText nid=field(body,"NID / পরিচিতি নম্বর",old==null?"":old.optString("nid"));
        EditText address=field(body,"গ্রাম, ইউনিয়ন, ব্লক",old==null?"":old.optString("address"));
        EditText details=field(body,"অতিরিক্ত তথ্য (জমি, ফসল, পরিমাণ, দল ইত্যাদি)",old==null?"":old.optString("details"));
        body.addView(btn("সংরক্ষণ করুন",()->{
            try{
                JSONObject x=old==null?new JSONObject():old;
                String id=old==null?UUID.randomUUID().toString():old.optString("id");
                x.put("id",id); x.put("category",cat); x.put("name",name.getText().toString().trim());
                x.put("father",father.getText().toString().trim()); x.put("mobile",mobile.getText().toString().trim());
                x.put("nid",nid.getText().toString().trim()); x.put("address",address.getText().toString().trim());
                x.put("details",details.getText().toString().trim());
                x.put("updated",new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss",Locale.US).format(new Date()));
                db.save(x,false); Toast.makeText(this,"মোবাইলে সংরক্ষিত হয়েছে",Toast.LENGTH_LONG).show(); showList(cat);
            }catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}
        }));
        body.addView(btn("ফিরে যান",()->showList(cat)));
    }
    void showList(String cat){
        start(cat);
        body.addView(btn("＋ নতুন যোগ করুন",()->showForm(cat,null)));
        JSONArray a=db.all();
        for(int i=0;i<a.length();i++){ JSONObject x=a.optJSONObject(i); if(!cat.equals(x.optString("category")))continue;
            LinearLayout card=new LinearLayout(this); card.setOrientation(1); card.setPadding(8,8,8,8); card.setBackgroundColor(0xFFFFFFFF);
            card.addView(text(x.optString("name"),18)); card.addView(text("মোবাইল: "+x.optString("mobile")+" | "+x.optString("address"),13));
            card.addView(text(x.optString("details"),13));
            card.addView(btn("সম্পাদনা",()->showForm(cat,x)));
            card.addView(btn("মুছুন",()->new AlertDialog.Builder(this).setMessage("তথ্যটি মুছবেন?").setPositiveButton("হ্যাঁ",(d,w)->{db.delete(x.optString("id"));showList(cat);}).setNegativeButton("না",null).show()));
            body.addView(card);
        }
        body.addView(btn("ড্যাশবোর্ডে ফিরুন",()->showHome()));
    }
    void settings(){
        start("Google Sheets সংযোগ");
        body.addView(text("১) Google Apps Script-এ দেওয়া Code.gs প্রকাশ করে Web App URL কপি করুন।\n২) URL এখানে পেস্ট করে সংরক্ষণ করুন।\n৩) Sync চাপুন।",15));
        endpoint=new EditText(this); endpoint.setHint("https://script.google.com/macros/s/.../exec");
        endpoint.setText(getPreferences(0).getString("endpoint","")); body.addView(endpoint);
        body.addView(btn("URL সংরক্ষণ করুন",()->{getPreferences(0).edit().putString("endpoint",endpoint.getText().toString().trim()).apply();Toast.makeText(this,"URL সংরক্ষিত",Toast.LENGTH_SHORT).show();}));
        body.addView(btn("এখন Sync করুন",()->sync()));
        body.addView(btn("ফিরে যান",()->showHome()));
    }
    void sync(){
        String url=getPreferences(0).getString("endpoint","");
        if(url.isEmpty()){Toast.makeText(this,"আগে Web App URL দিন",Toast.LENGTH_LONG).show();return;}
        Toast.makeText(this,"সিঙ্ক শুরু হয়েছে; কিছুক্ষণ অপেক্ষা করুন",Toast.LENGTH_LONG).show();
        new Thread(()->{
            try{
                URL u=new URL(url); HttpURLConnection c=(HttpURLConnection)u.openConnection();
                c.setRequestMethod("POST"); c.setDoOutput(true); c.setConnectTimeout(20000); c.setReadTimeout(20000);
                c.setRequestProperty("Content-Type","application/json; charset=UTF-8");
                JSONObject payload=new JSONObject(); payload.put("action","sync"); payload.put("records",db.pending());
                OutputStream os=c.getOutputStream(); os.write(payload.toString().getBytes("UTF-8")); os.close();
                String response=read(c.getInputStream()); c.disconnect();
                JSONObject result=new JSONObject(response); JSONArray remote=result.optJSONArray("records");
                if(remote!=null)for(int i=0;i<remote.length();i++)db.save(remote.getJSONObject(i),true);
                db.markAllSynced();
                runOnUiThread(()->{Toast.makeText(this,"সিঙ্ক সম্পন্ন",Toast.LENGTH_LONG).show();showHome();});
            }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"সিঙ্ক হয়নি: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }).start();
    }
    String read(InputStream in)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder s=new StringBuilder();String l;while((l=r.readLine())!=null)s.append(l);return s.toString();}
}
